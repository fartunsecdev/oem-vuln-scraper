#!/usr/bin/env python3
"""
Test script to demonstrate the compliance mapping functionality.
"""

import sys
from oem_scraper import Vulnerability
from storage import VulnerabilityStorage
from compliance_mapping import get_compliance_mapper

def create_test_vulnerabilities():
    """Create test vulnerabilities representing different vendors and severities."""
    vulnerabilities = []
    
    # 1. Critical Microsoft vulnerability
    vulnerabilities.append(Vulnerability(
        product_name="Windows Server 2022",
        product_version="All versions",
        oem_name="Microsoft",
        severity_level="Critical",
        description="Remote code execution vulnerability in Windows Server",
        mitigation_strategy="Apply latest security update",
        remediation_steps="1. Download and install KB12345678\n2. Restart the server",
        patch_links="https://microsoft.com/kb12345678",
        published_date="2025-04-05",
        unique_id="CVE-2025-0001",
        url="https://msrc.microsoft.com/update-guide/vulnerability/CVE-2025-0001"
    ))
    
    # 2. High severity Cisco vulnerability
    vulnerabilities.append(Vulnerability(
        product_name="Cisco IOS XE",
        product_version="17.x",
        oem_name="Cisco",
        severity_level="High",
        description="Authentication bypass vulnerability in Cisco IOS XE",
        mitigation_strategy="Upgrade to patched version",
        remediation_steps="1. Upgrade to version 17.9.2 or later\n2. Implement access control lists",
        patch_links="https://cisco.com/security/advisory/cisco-sa-20250405-iosxe",
        published_date="2025-04-05",
        unique_id="CVE-2025-0002",
        url="https://tools.cisco.com/security/center/content/CiscoSecurityAdvisory/cisco-sa-20250405-iosxe"
    ))
    
    # 3. Critical Siemens OT vulnerability
    vulnerabilities.append(Vulnerability(
        product_name="SIMATIC S7-1500 PLC",
        product_version="All versions",
        oem_name="Siemens",
        severity_level="Critical",
        description="Unauthenticated remote code execution in SIMATIC S7-1500",
        mitigation_strategy="Apply security update",
        remediation_steps="1. Download firmware update from Siemens\n2. Update PLC firmware\n3. Implement network segmentation",
        patch_links="https://cert-portal.siemens.com/productcert/pdf/ssa-12345.pdf",
        published_date="2025-04-05",
        unique_id="CVE-2025-0003",
        url="https://cert-portal.siemens.com/productcert/html/ssa-12345.html"
    ))
    
    # 4. Medium severity vulnerability
    vulnerabilities.append(Vulnerability(
        product_name="Google Chrome",
        product_version="120.0.6099.129",
        oem_name="Google",
        severity_level="Medium",
        description="Information disclosure vulnerability in Chrome Browser",
        mitigation_strategy="Update to latest version",
        remediation_steps="Update Chrome to version 120.0.6099.130 or later",
        patch_links="https://chromereleases.googleblog.com/2025/04/stable-channel-update.html",
        published_date="2025-04-05",
        unique_id="CVE-2025-0004",
        url="https://chromereleases.googleblog.com/2025/04/stable-channel-update.html"
    ))
    
    return vulnerabilities

def test_compliance_mappings():
    """Test the compliance mapping functionality."""
    print("\nCOMPLIANCE MAPPING TEST\n" + "="*50)
    
    # Create test vulnerabilities
    vulnerabilities = create_test_vulnerabilities()
    
    # Get compliance mapper
    mapper = get_compliance_mapper()
    
    # Add vulnerabilities to storage
    storage = VulnerabilityStorage("test_compliance_db.json")
    for vuln in vulnerabilities:
        storage.add_vulnerability(vuln)
    
    # Export to CSV with compliance information
    storage.export_csv("test_compliance.csv")
    print(f"Exported vulnerabilities with compliance info to test_compliance.csv")
    
    # Display compliance reports for each vulnerability
    for i, vuln in enumerate(vulnerabilities, 1):
        print(f"\nVulnerability #{i}: {vuln.unique_id} - {vuln.product_name}")
        print(f"Severity: {vuln.severity_level}")
        print(f"Vendor: {vuln.oem_name}")
        print("\n" + vuln.get_compliance_report())
        print("-" * 50)
    
    # Generate summary report
    print("\nCOMPLIANCE SUMMARY REPORT:")
    framework_counts = {
        "NIST CSF": 0,
        "ISO 27001": 0,
        "IEC 62443": 0
    }
    control_counts = {}
    
    for vuln in vulnerabilities:
        compliance_map = mapper.map_vulnerability(vuln)
        for framework, requirements in compliance_map.items():
            framework_counts[framework] = framework_counts.get(framework, 0) + 1
            for req in requirements:
                key = f"{framework}:{req.control_id}"
                control_counts[key] = control_counts.get(key, 0) + 1
    
    print("\nFramework Coverage:")
    for framework, count in framework_counts.items():
        print(f"  {framework}: {count}/{len(vulnerabilities)} vulnerabilities")
    
    print("\nTop Affected Controls:")
    sorted_controls = sorted(control_counts.items(), key=lambda x: x[1], reverse=True)
    for i, (control, count) in enumerate(sorted_controls[:5], 1):
        framework, control_id = control.split(":", 1)
        print(f"  {i}. {framework} {control_id}: {count} vulnerabilities")
    
    print("\nTest completed successfully! Check test_compliance.csv for the full export.")

if __name__ == "__main__":
    test_compliance_mappings() 