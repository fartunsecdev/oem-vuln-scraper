#!/usr/bin/env python3
"""
Notifier module for the OEM Vulnerability Scraper.

This module handles email notifications for newly discovered vulnerabilities.
"""

import os
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

logger = logging.getLogger("notifier")

class EmailNotifier:
    """Email notification handler for vulnerabilities."""
    
    def __init__(self, smtp_server=None, smtp_port=None, username=None, password=None):
        """Initialize email notifier with SMTP settings."""
        self.smtp_server = smtp_server or os.getenv("SMTP_SERVER")
        self.smtp_port = smtp_port or os.getenv("SMTP_PORT")
        self.username = username or os.getenv("EMAIL_USERNAME")
        self.password = password or os.getenv("EMAIL_PASSWORD")
        
        # Validate configuration
        if not all([self.smtp_server, self.smtp_port, self.username, self.password]):
            logger.warning("Email configuration is incomplete. Notifications will not be sent.")
            
        # Parse recipient email addresses
        recipient_emails = os.getenv("RECIPIENT_EMAILS", "")
        self.recipients = [email.strip() for email in recipient_emails.split(",") if email.strip()]
        if not self.recipients:
            logger.warning("No recipient emails configured. Notifications will not be sent.")
    
    def is_configured(self):
        """Check if email notification is properly configured."""
        return all([self.smtp_server, self.smtp_port, self.username, self.password, self.recipients])
    
    def send_vulnerability_notification(self, vulnerabilities):
        """Send email notification about new vulnerabilities."""
        if not self.is_configured():
            logger.error("Email notification is not properly configured. Cannot send notification.")
            return False
            
        if not vulnerabilities:
            logger.info("No vulnerabilities to report. Skipping notification.")
            return False
        
        # Create email message
        msg = MIMEMultipart()
        msg['From'] = self.username
        msg['To'] = ", ".join(self.recipients)
        
        # Set subject with count
        current_date = datetime.now().strftime("%Y-%m-%d")
        msg['Subject'] = f"SECURITY ALERT: {len(vulnerabilities)} Critical/High Severity Vulnerabilities Detected - {current_date}"
        
        # Create email body
        body = self._create_email_body(vulnerabilities)
        msg.attach(MIMEText(body, 'plain'))
        
        # Send email
        try:
            with smtplib.SMTP(self.smtp_server, int(self.smtp_port)) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)
            
            logger.info(f"Successfully sent vulnerability notification to {len(self.recipients)} recipients")
            return True
        except Exception as e:
            logger.error(f"Failed to send email notification: {e}")
            return False
    
    def _create_email_body(self, vulnerabilities):
        """Create the email body from vulnerabilities."""
        body = f"""SECURITY ALERT: Critical and High Severity Vulnerabilities

{len(vulnerabilities)} new critical/high severity vulnerabilities have been detected.

"""
        # Add vulnerability details
        for i, vuln in enumerate(vulnerabilities, 1):
            body += f"\n{'='*50}\nVULNERABILITY #{i}\n{'='*50}\n"
            
            if isinstance(vuln, dict):
                # If vuln is a dictionary (from storage)
                body += f"""
SUMMARY:
---------
* Product Name: {vuln.get('product_name', 'N/A')}
* Product Version: {vuln.get('product_version', 'N/A')}
* OEM name: {vuln.get('oem_name', 'N/A')}
* Severity Level: {vuln.get('severity_level', 'N/A')}
* Vulnerability: {vuln.get('description', 'N/A')}
* Published Date: {vuln.get('published_date', 'N/A')}
* Unique ID: {vuln.get('unique_id', 'N/A')}
* Source URL: {vuln.get('url', 'N/A')}

REMEDIATION:
------------
* Mitigation Strategy: {vuln.get('mitigation_strategy', 'N/A')}

DETAILED REMEDIATION STEPS:
--------------------------
{vuln.get('remediation_steps', 'N/A')}

PATCH / UPDATE LINKS:
--------------------
{vuln.get('patch_links', 'N/A')}
"""
                # We can't get compliance report from dict objects
                body += "\nCOMPLIANCE REQUIREMENTS:\nCompliance mapping available for object instances only."
                
            else:
                # If vuln is a Vulnerability object
                body += f"""
SUMMARY:
---------
* Product Name: {vuln.product_name}
* Product Version: {vuln.product_version}
* OEM name: {vuln.oem_name}
* Severity Level: {vuln.severity_level}
* Vulnerability: {vuln.description}
* Published Date: {vuln.published_date}
* Unique ID: {vuln.unique_id}
* Source URL: {vuln.url}

REMEDIATION:
------------
* Mitigation Strategy: {vuln.mitigation_strategy}

DETAILED REMEDIATION STEPS:
--------------------------
{vuln.remediation_steps}

PATCH / UPDATE LINKS:
--------------------
{vuln.patch_links}

{vuln.get_compliance_report()}
"""
        
        body += "\n\n---\nThis is an automated security alert from the OEM Vulnerability Scraper."
        body += "\nPlease take appropriate action to address these vulnerabilities."
        body += "\n\nFor assistance with remediation, contact your security team."
        body += "\nFor compliance-related inquiries, contact your compliance officer."
        
        return body
        
    def send_test_email(self):
        """Send a test email to verify configuration."""
        if not self.is_configured():
            logger.error("Email notification is not properly configured. Cannot send test email.")
            return False
            
        # Create email message
        msg = MIMEMultipart()
        msg['From'] = self.username
        msg['To'] = ", ".join(self.recipients)
        msg['Subject'] = "Test Email from OEM Vulnerability Scraper"
        
        body = """This is a test email from the OEM Vulnerability Scraper.

If you are receiving this email, your email notification configuration is working correctly.

---
OEM Vulnerability Scraper
"""
        msg.attach(MIMEText(body, 'plain'))
        
        # Send email
        try:
            with smtplib.SMTP(self.smtp_server, int(self.smtp_port)) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)
            
            logger.info(f"Successfully sent test email to {len(self.recipients)} recipients")
            return True
        except Exception as e:
            logger.error(f"Failed to send test email: {e}")
            return False 