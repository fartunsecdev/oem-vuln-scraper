"""
OEM Vulnerability Scraper

A tool for monitoring critical and high severity vulnerabilities of OEM equipment
(IT and OT) published at respective OEM websites and other relevant web platforms.
"""

__version__ = "1.0.0" 