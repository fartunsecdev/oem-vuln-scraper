#!/usr/bin/env python3
"""
OEM Vulnerability Scraper

This module handles scraping of OEM websites for vulnerability information.
It focuses on detecting critical and high severity vulnerabilities and reporting them.
"""

import os
import re
import json
import logging
import requests
import datetime
import feedparser
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from dataclasses import dataclass, asdict, field

# Configure logging
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("vuln_scraper.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("oem_scraper")

@dataclass
class Vulnerability:
    """Represents a vulnerability with all its attributes."""
    product_name: str
    product_version: str = "N/A"
    oem_name: str = "N/A"
    severity_level: str = "N/A"
    description: str = "N/A"
    mitigation_strategy: str = "N/A"
    remediation_steps: str = "N/A"  # Detailed steps for remediation
    patch_links: str = "N/A"  # Links to patches or updates
    published_date: str = "N/A"
    unique_id: str = "N/A"
    url: str = "N/A"
    last_updated: str = field(default_factory=lambda: datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    _compliance_report: str = field(default="", init=False, repr=False)
    
    def is_critical_or_high(self):
        """Check if the vulnerability is Critical or High severity."""
        if not self.severity_level:
            return False
        return any(level in self.severity_level.lower() for level in ["critical", "high"])
    
    def to_dict(self):
        """Convert to dictionary."""
        data = asdict(self)
        # Remove private fields
        return {k: v for k, v in data.items() if not k.startswith('_')}
    
    def to_email_format(self):
        """Format for email reporting."""
        return f"""
* Product Name: {self.product_name}
* Product Version: {self.product_version}
* OEM name: {self.oem_name}
* Severity Level: {self.severity_level}
* Vulnerability: {self.description}
* Mitigation Strategy: {self.mitigation_strategy}
* Remediation Steps: {self.remediation_steps}
* Patch/Update Links: {self.patch_links}
* Published Date: {self.published_date}
* Unique ID: {self.unique_id}
* Source URL: {self.url}
"""

    def get_compliance_report(self):
        """Get compliance mapping report for this vulnerability."""
        if not self._compliance_report:
            try:
                # Import here to avoid circular imports
                from compliance_mapping import get_compliance_mapper
                mapper = get_compliance_mapper()
                self._compliance_report = mapper.get_compliance_report(self)
            except ImportError:
                self._compliance_report = "Compliance mapping module not available."
            except Exception as e:
                self._compliance_report = f"Error generating compliance report: {e}"
                
        return self._compliance_report

class OEMScraper:
    """Base class for OEM-specific scrapers."""
    
    def __init__(self, name, base_url):
        self.name = name
        self.base_url = base_url
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)
        
    def get_page(self, url):
        """Fetch a page and return its content."""
        try:
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            logger.error(f"Error fetching {url}: {e}")
            return None
    
    def parse_severity(self, text):
        """Extract severity level from text."""
        if not text:
            return None
            
        text = text.lower()
        
        if "critical" in text:
            return "Critical"
        elif "high" in text:
            return "High"
        elif "medium" in text:
            return "Medium"
        elif "low" in text:
            return "Low"
        else:
            return "Unknown"
    
    def extract_date(self, text):
        """Extract date from text using various formats."""
        if not text:
            return "N/A"
            
        # Try common date formats
        date_patterns = [
            r'(\d{1,2}[-/]\d{1,2}[-/]\d{2,4})',  # DD/MM/YYYY or MM/DD/YYYY
            r'(\d{4}[-/]\d{1,2}[-/]\d{1,2})',    # YYYY/MM/DD
            r'([A-Z][a-z]{2}\s+\d{1,2},\s+\d{4})',  # Jan 1, 2023
            r'(\d{1,2}\s+[A-Z][a-z]{2}\s+\d{4})'    # 1 Jan 2023
        ]
        
        for pattern in date_patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
                
        # If no pattern matched, try to find month and year
        months = ["January", "February", "March", "April", "May", "June", 
                  "July", "August", "September", "October", "November", "December"]
        
        for month in months:
            if month in text or month[:3] in text:
                year_match = re.search(r'\b(20\d{2})\b', text)
                if year_match:
                    return f"{month} {year_match.group(1)}"
        
        return "N/A"
    
    def extract_cve(self, text):
        """Extract CVE IDs from text."""
        if not text:
            return "N/A"
            
        cve_pattern = r'CVE-\d{4}-\d{4,}'
        matches = re.findall(cve_pattern, text)
        
        if matches:
            return matches[0]
        return "N/A"
    
    def scrape(self):
        """
        Main method to scrape vulnerabilities.
        Must be implemented by subclasses.
        """
        raise NotImplementedError("Subclasses must implement this method")


class ScraperRegistry:
    """Registry of all OEM scrapers."""
    
    _scrapers = {}
    
    @classmethod
    def register(cls, scraper_class):
        """Register a scraper class."""
        instance = scraper_class()
        cls._scrapers[instance.name] = instance
        return scraper_class
    
    @classmethod
    def get_all_scrapers(cls):
        """Get all registered scrapers."""
        return cls._scrapers.values()
    
    @classmethod
    def get_scraper(cls, name):
        """Get a specific scraper by name."""
        return cls._scrapers.get(name)


# Example concrete scraper implementations
@ScraperRegistry.register
class CiscaScraper(OEMScraper):
    """Scraper for Cisco security advisories."""
    
    def __init__(self):
        super().__init__("Cisco", "https://tools.cisco.com/security/center/publicationListing.x")
        
    def extract_remediation_info(self, advisory_url):
        """Extract detailed remediation steps and patch links from an advisory."""
        page_content = self.get_page(advisory_url)
        if not page_content:
            return "No remediation information available", "No patch links available"
            
        soup = BeautifulSoup(page_content, 'lxml')
        
        # Try to find remediation section - Cisco often has "Fixed Software" or "Workarounds" sections
        remediation_steps = "See advisory for detailed remediation steps"
        patch_links = "See advisory for patch information"
        
        # Look for fixed software section
        fixed_software_section = soup.find('h3', text=re.compile('Fixed Software', re.I))
        if fixed_software_section:
            next_element = fixed_software_section.find_next('p')
            if next_element:
                remediation_steps = next_element.get_text(strip=True)
                
        # Look for workarounds section
        workarounds_section = soup.find('h3', text=re.compile('Workarounds', re.I))
        if workarounds_section:
            workaround_text = []
            next_element = workarounds_section.find_next('p')
            while next_element and next_element.name != 'h3':
                if next_element.name == 'p':
                    workaround_text.append(next_element.get_text(strip=True))
                next_element = next_element.find_next()
            
            if workaround_text:
                if remediation_steps == "See advisory for detailed remediation steps":
                    remediation_steps = " ".join(workaround_text[:3])  # Limit to first 3 paragraphs
                else:
                    remediation_steps += "\n\nWorkarounds: " + " ".join(workaround_text[:2])
                    
        # Look for software download links
        download_links = []
        for a in soup.find_all('a', href=re.compile('download', re.I)):
            if 'software' in a.get_text().lower():
                download_links.append(f"{a.get_text().strip()}: {a['href']}")
                
        if download_links:
            patch_links = "\n".join(download_links[:3])  # Limit to first 3 links
            
        return remediation_steps, patch_links
        
    def scrape(self):
        """Scrape Cisco security advisories."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        page_content = self.get_page(self.base_url)
        if not page_content:
            return []
            
        soup = BeautifulSoup(page_content, 'lxml')
        vulnerabilities = []
        
        # Find the advisory table
        advisory_table = soup.find('table', class_='table-striped')
        if not advisory_table:
            logger.warning(f"Could not find advisory table on {self.base_url}")
            return []
            
        # Process each row in the table
        for row in advisory_table.find_all('tr')[1:]:  # Skip header row
            columns = row.find_all('td')
            if len(columns) < 5:
                continue
                
            # Extract data from columns
            advisory_link = columns[0].find('a', href=True)
            if not advisory_link:
                continue
                
            advisory_url = urljoin(self.base_url, advisory_link['href'])
            advisory_id = advisory_link.text.strip()
            advisory_title = columns[1].text.strip()
            severity = self.parse_severity(columns[2].text.strip())
            
            # Skip if not critical or high
            if severity not in ['Critical', 'High']:
                continue
                
            published_date = self.extract_date(columns[3].text.strip())
            cve_id = self.extract_cve(advisory_title)
            if cve_id == "N/A":
                cve_id = advisory_id
                
            # Get detailed remediation information
            remediation_steps, patch_links = self.extract_remediation_info(advisory_url)
                
            # Create vulnerability object
            vulnerability = Vulnerability(
                product_name=advisory_title.split(':')[0] if ':' in advisory_title else advisory_title,
                product_version="See advisory for affected versions",
                oem_name=self.name,
                severity_level=severity,
                description=advisory_title,
                mitigation_strategy="Update to a fixed software version or apply workarounds",
                remediation_steps=remediation_steps,
                patch_links=patch_links,
                published_date=published_date,
                unique_id=cve_id,
                url=advisory_url
            )
            
            vulnerabilities.append(vulnerability)
            
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


@ScraperRegistry.register
class MicrosoftScraper(OEMScraper):
    """Scraper for Microsoft security bulletins."""
    
    def __init__(self):
        super().__init__("Microsoft", "https://api.msrc.microsoft.com/cvrf/v2.0/updates")
        
    def extract_remediation_info(self, cve_id):
        """Extract detailed remediation information for a specific CVE."""
        # Microsoft Security Response Center CVE details
        msrc_url = f"https://msrc.microsoft.com/update-guide/vulnerability/{cve_id}"
        
        page_content = self.get_page(msrc_url)
        if not page_content:
            return "See Microsoft advisory for remediation details", "Visit Windows Update or Microsoft Update Catalog"
            
        soup = BeautifulSoup(page_content, 'lxml')
        
        # Extract remediation steps
        remediation_steps = []
        remediation_section = soup.find(text=re.compile('Workarounds', re.I))
        if remediation_section:
            remediation_parent = remediation_section.parent
            for sibling in remediation_parent.find_next_siblings():
                if sibling.name == 'h2' or sibling.name == 'h3':
                    break
                if sibling.name == 'p' or sibling.name == 'ul':
                    remediation_steps.append(sibling.get_text(strip=True))
        
        # Extract KB article numbers for patches
        kb_numbers = []
        for kb_match in re.finditer(r'KB(\d+)', page_content):
            kb_numbers.append(kb_match.group(0))
        
        # Create patch links
        patch_links = []
        if kb_numbers:
            for kb in set(kb_numbers)[:3]:  # Limit to first 3 unique KB articles
                patch_links.append(f"Microsoft Update KB Article: https://support.microsoft.com/help/{kb}")
        
        # Add Windows Update link
        patch_links.append("Windows Update: https://update.microsoft.com")
        patch_links.append("Microsoft Update Catalog: https://www.catalog.update.microsoft.com")
        
        remediation_text = "Microsoft recommends applying the latest security updates. "
        if remediation_steps:
            remediation_text += "Workarounds: " + " ".join(remediation_steps[:3])  # Limit to first 3 items
        else:
            remediation_text += "See the Microsoft Security Update Guide for details."
            
        patch_links_text = "\n".join(patch_links)
        
        return remediation_text, patch_links_text
    
    def scrape(self):
        """Scrape Microsoft security bulletins."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        # Get list of security updates
        updates_content = self.get_page(self.base_url)
        if not updates_content:
            return []
            
        updates = json.loads(updates_content).get('value', [])
        if not updates:
            logger.warning("No Microsoft security updates found")
            return []
            
        vulnerabilities = []
        
        # Process each update
        for update in updates:
            update_id = update.get('ID')
            if not update_id:
                continue
                
            # Get detailed update information
            update_url = f"https://api.msrc.microsoft.com/cvrf/v2.0/document/{update_id}"
            update_content = self.get_page(update_url)
            
            if not update_content:
                logger.error(f"Error fetching Microsoft update {update_id}")
                continue
                
            try:
                update_data = json.loads(update_content)
                
                # Extract vulnerabilities
                vuln_details = update_data.get('Vulnerability', [])
                for vuln in vuln_details:
                    # Get CVE ID
                    cve_id = vuln.get('CVE')
                    if not cve_id:
                        continue
                        
                    # Get severity
                    threats = vuln.get('Threats', [])
                    severity = None
                    for threat in threats:
                        if threat.get('Type') == 0:  # Severity rating
                            severity = threat.get('Description', {}).get('Value')
                            break
                            
                    if not severity or severity not in ["Critical", "Important"]:  # Important is Microsoft's term for High
                        continue
                        
                    # Get product information
                    product_id = None
                    for threat in threats:
                        if threat.get('Type') == 1:  # Product family
                            product_id = threat.get('ProductID', [])[0] if threat.get('ProductID') else None
                            break
                            
                    product_name = "Microsoft Product"
                    if product_id:
                        for product in update_data.get('ProductTree', {}).get('FullProductName', []):
                            if product.get('ProductID') == product_id:
                                product_name = product.get('Value', "Microsoft Product")
                                break
                                
                    # Get title and description
                    title = vuln.get('Title', {}).get('Value', f"Microsoft {cve_id}")
                    description = vuln.get('Notes', [{}])[0].get('Value', "See Microsoft advisory for details") if vuln.get('Notes') else "See Microsoft advisory for details"
                    
                    # Get remediation
                    remediation = "Apply the latest Microsoft security updates"
                    
                    # Get detailed remediation information
                    remediation_steps, patch_links = self.extract_remediation_info(cve_id)
                    
                    # Create vulnerability object
                    vulnerability = Vulnerability(
                        product_name=product_name,
                        product_version="See Microsoft advisory for affected versions",
                        oem_name=self.name,
                        severity_level=severity,
                        description=description,
                        mitigation_strategy=remediation,
                        remediation_steps=remediation_steps,
                        patch_links=patch_links,
                        published_date=update.get('CurrentReleaseDate', 'N/A'),
                        unique_id=cve_id,
                        url=f"https://msrc.microsoft.com/update-guide/vulnerability/{cve_id}"
                    )
                    
                    vulnerabilities.append(vulnerability)
                    
            except json.JSONDecodeError as e:
                logger.error(f"Error parsing Microsoft update {update_id}: {e}")
                continue
                
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


@ScraperRegistry.register
class GoogleScraper(OEMScraper):
    """Scraper for Google Chrome security advisories."""
    
    def __init__(self):
        super().__init__("Google", "https://chromereleases.googleblog.com/")
        
    def extract_remediation_info(self, version, cve_id):
        """Extract detailed remediation information for Chrome vulnerabilities."""
        # Google Chrome releases typically provide update instructions
        remediation_steps = (
            f"Update Google Chrome to version {version} or later:\n"
            "1. Open Chrome and click the three dots in the top-right corner\n"
            "2. Go to Help > About Google Chrome\n"
            "3. Chrome will automatically check for updates and install them\n"
            "4. Restart Chrome to complete the update"
        )
        
        # Create patch links
        patch_links = [
            f"Chrome Download: https://www.google.com/chrome/",
            f"Chrome Enterprise: https://chromeenterprise.google/browser/download/",
            f"CVE Details: https://cve.mitre.org/cgi-bin/cvename.cgi?name={cve_id}"
        ]
        
        return remediation_steps, "\n".join(patch_links)
    
    def scrape(self):
        """Scrape Google Chrome security advisories."""
        logger.info(f"Scraping {self.name} Chrome vulnerabilities")
        
        page_content = self.get_page(self.base_url)
        if not page_content:
            return []
            
        soup = BeautifulSoup(page_content, 'lxml')
        vulnerabilities = []
        
        # Find security update posts
        security_posts = []
        for post in soup.find_all('div', class_='post'):
            title = post.find('h2', class_='title')
            if title and ('security' in title.text.lower() or 'vulnerabilities' in title.text.lower() or 'stable channel' in title.text.lower()):
                security_posts.append(post)
                
        # Parse each security post
        for post in security_posts[:5]:  # Limit to the 5 most recent security posts
            title = post.find('h2', class_='title').text.strip()
            
            # Extract Chrome version
            version_match = re.search(r'Chrome (?:for \w+\s)?(\d+\.\d+\.\d+\.\d+)', title)
            chrome_version = version_match.group(1) if version_match else "Latest"
            
            # Get post URL
            post_url = post.find('a', text='Permalink')['href'] if post.find('a', text='Permalink') else self.base_url
            
            # Get full post content
            post_content = self.get_page(post_url)
            if not post_content:
                continue
                
            post_soup = BeautifulSoup(post_content, 'lxml')
            content_div = post_soup.find('div', class_='post-body')
            
            if not content_div:
                continue
                
            # Extract CVEs
            cve_pattern = r'CVE-\d{4}-\d{4,}'
            cve_matches = re.findall(cve_pattern, content_div.text)
            
            # Extract severity information
            high_critical_pattern = r'(?:High|Critical).*?CVE-\d{4}-\d{4,}'
            high_critical_sections = re.findall(high_critical_pattern, content_div.text, re.DOTALL)
            
            # Process each high/critical vulnerability
            for section in high_critical_sections:
                severity = "High" if "High" in section else "Critical"
                cve_match = re.search(cve_pattern, section)
                
                if not cve_match:
                    continue
                    
                cve_id = cve_match.group(0)
                
                # Extract description - get text between severity and CVE
                description_match = re.search(r'(?:High|Critical)[:\s]+(.*?)\s+' + cve_id, section, re.DOTALL)
                description = description_match.group(1).strip() if description_match else "See Chrome release notes for details"
                
                # Clean up description
                description = re.sub(r'\s+', ' ', description)
                
                # Extract published date
                date_div = post_soup.find('div', class_='date')
                published = date_div.text.strip() if date_div else "N/A"
                
                # Get detailed remediation information
                remediation_steps, patch_links = self.extract_remediation_info(chrome_version, cve_id)
                
                # Create vulnerability object
                vulnerability = Vulnerability(
                    product_name="Google Chrome",
                    product_version=chrome_version,
                    oem_name=self.name,
                    severity_level=severity,
                    description=description,
                    mitigation_strategy="Update to the latest version of Chrome",
                    remediation_steps=remediation_steps,
                    patch_links=patch_links,
                    published_date=published,
                    unique_id=cve_id,
                    url=post_url
                )
                
                vulnerabilities.append(vulnerability)
                
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


def get_all_vulnerabilities():
    """
    Fetch vulnerabilities from all registered OEM scrapers.
    Returns only Critical and High severity vulnerabilities.
    """
    all_vulnerabilities = []
    
    for scraper in ScraperRegistry.get_all_scrapers():
        try:
            vulnerabilities = scraper.scrape()
            # Filter for critical and high only
            critical_high_vulns = [v for v in vulnerabilities if v.is_critical_or_high()]
            all_vulnerabilities.extend(critical_high_vulns)
        except Exception as e:
            logger.error(f"Error with scraper {scraper.name}: {e}")
    
    return all_vulnerabilities


if __name__ == "__main__":
    # For testing scrapers directly
    vulnerabilities = get_all_vulnerabilities()
    for vuln in vulnerabilities:
        print(f"{vuln.oem_name} - {vuln.unique_id} - {vuln.severity_level}")
        print(vuln.to_email_format())
        print("-" * 80) 