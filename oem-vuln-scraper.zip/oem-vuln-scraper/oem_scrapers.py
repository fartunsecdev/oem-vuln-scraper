#!/usr/bin/env python3
"""
OEM-specific scrapers for vulnerability information.

This module provides concrete implementations of scrapers for various OEM websites.
"""

import re
import json
import logging
import requests
import datetime
import feedparser
from bs4 import BeautifulSoup
from urllib.parse import urljoin

from oem_scraper import OEMScraper, ScraperRegistry, Vulnerability

logger = logging.getLogger("oem_scrapers")

@ScraperRegistry.register
class SiemensScraper(OEMScraper):
    """Scraper for Siemens ProductCERT Security Advisories."""
    
    def __init__(self):
        super().__init__("Siemens", "https://cert-portal.siemens.com/productcert/json/advisories.json")
        
    def scrape(self):
        """Scrape Siemens security advisories."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        try:
            response = self.session.get(self.base_url)
            response.raise_for_status()
            advisories = response.json()
        except (requests.RequestException, json.JSONDecodeError) as e:
            logger.error(f"Error fetching Siemens advisories: {e}")
            return []
            
        vulnerabilities = []
        
        for advisory in advisories:
            # Get severity
            severity = advisory.get("Severity")
            if not severity or severity not in ["Critical", "High"]:
                continue
                
            # Get advisory details
            advisory_id = advisory.get("ID")
            cve_ids = advisory.get("CVE") or []
            title = advisory.get("Title", "Unknown vulnerability")
            update_date = advisory.get("UpdateDate")
            
            # Get products
            affected_products = advisory.get("AffectedProduct", [])
            if not affected_products:
                product_name = "Siemens Industrial Products" 
            else:
                # Join first few product names
                product_name = ", ".join(affected_products[:3])
                if len(affected_products) > 3:
                    product_name += "..."
            
            # Get URL for more details
            advisory_url = f"https://cert-portal.siemens.com/productcert/pdf/{advisory_id}.pdf"
            
            # Create vulnerability entry
            cve_id = cve_ids[0] if cve_ids else "N/A"
            vulnerability = Vulnerability(
                product_name=product_name,
                product_version="See advisory for details",
                oem_name=self.name,
                severity_level=severity,
                description=title,
                mitigation_strategy="See advisory for details",
                published_date=update_date,
                unique_id=cve_id,
                url=advisory_url
            )
            
            vulnerabilities.append(vulnerability)
            
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


@ScraperRegistry.register
class SchneiderElectricScraper(OEMScraper):
    """Scraper for Schneider Electric security notifications."""
    
    def __init__(self):
        super().__init__("Schneider Electric", "https://www.se.com/ww/en/work/support/cybersecurity/security-notifications.jsp")
        
    def scrape(self):
        """Scrape Schneider Electric security notifications."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        page_content = self.get_page(self.base_url)
        if not page_content:
            return []
            
        soup = BeautifulSoup(page_content, 'lxml')
        vulnerabilities = []
        
        # Find security notifications
        notification_links = soup.select('a[href*="security-notification"]')
        
        for link in notification_links[:20]:  # Process the most recent 20 notifications
            advisory_url = urljoin(self.base_url, link.get('href', ''))
            if not advisory_url:
                continue
                
            # Get advisory details
            advisory_content = self.get_page(advisory_url)
            if not advisory_content:
                continue
                
            advisory_soup = BeautifulSoup(advisory_content, 'lxml')
            
            # Check for severity
            severity_text = None
            severity_section = advisory_soup.find(text=re.compile('CVSS|Severity|Risk', re.I))
            if severity_section:
                # Look for severity in the text nearby
                parent = severity_section.parent
                for sibling in parent.find_next_siblings():
                    if sibling.get_text():
                        severity_text = sibling.get_text()
                        break
                
            severity = self.parse_severity(severity_text)
            if not severity or severity not in ["Critical", "High"]:
                continue
                
            # Extract title
            title = link.get_text().strip()
            if not title:
                title_element = advisory_soup.find('h1') or advisory_soup.find('h2')
                if title_element:
                    title = title_element.get_text().strip()
                else:
                    title = "Schneider Electric Security Notification"
            
            # Extract CVE
            cve_id = self.extract_cve(advisory_content)
            
            # Extract publication date
            date_text = None
            date_section = advisory_soup.find(text=re.compile('Date|Published|Release', re.I))
            if date_section:
                parent = date_section.parent
                for sibling in parent.find_next_siblings():
                    if sibling.get_text():
                        date_text = sibling.get_text()
                        break
            
            published_date = self.extract_date(date_text) if date_text else "N/A"
            
            # Extract affected products
            product_name = "Schneider Electric Products"
            product_section = advisory_soup.find(text=re.compile('Affected Product|Vulnerable Product', re.I))
            if product_section:
                parent = product_section.parent
                for sibling in parent.find_next_siblings():
                    if sibling.get_text():
                        products_text = sibling.get_text().strip()
                        if products_text:
                            product_name = products_text.split("\n")[0][:100]  # Take first line, limit length
                            break
            
            # Extract mitigation
            mitigation = "See advisory for details"
            mitigation_section = advisory_soup.find(text=re.compile('Mitigation|Remediation|Solution', re.I))
            if mitigation_section:
                parent = mitigation_section.parent
                for sibling in parent.find_next_siblings():
                    if sibling.get_text():
                        mitigation = sibling.get_text().strip()[:200]  # Limit length
                        break
            
            # Create vulnerability entry
            vulnerability = Vulnerability(
                product_name=product_name,
                product_version="See advisory for details",
                oem_name=self.name,
                severity_level=severity,
                description=title,
                mitigation_strategy=mitigation,
                published_date=published_date,
                unique_id=cve_id,
                url=advisory_url
            )
            
            vulnerabilities.append(vulnerability)
            
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


@ScraperRegistry.register
class RockwellAutomationScraper(OEMScraper):
    """Scraper for Rockwell Automation security advisories."""
    
    def __init__(self):
        super().__init__("Rockwell Automation", "https://rockwellautomation.custhelp.com/app/answers/answer_list/search/1/kw/security/search/1")
        
    def scrape(self):
        """Scrape Rockwell Automation security advisories."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        page_content = self.get_page(self.base_url)
        if not page_content:
            return []
            
        soup = BeautifulSoup(page_content, 'lxml')
        vulnerabilities = []
        
        # Find security advisories
        advisory_links = soup.select('a[href*="answer_view"]')
        
        for link in advisory_links[:20]:  # Process the most recent 20 advisories
            advisory_title = link.get_text().strip()
            
            # Only process security advisories
            if not any(term in advisory_title.lower() for term in ['security', 'vulnerability', 'advisory']):
                continue
                
            advisory_url = urljoin(self.base_url, link.get('href', ''))
            if not advisory_url:
                continue
                
            # Get advisory details
            advisory_content = self.get_page(advisory_url)
            if not advisory_content:
                continue
                
            advisory_soup = BeautifulSoup(advisory_content, 'lxml')
            
            # Check for severity
            severity_text = None
            for term in ['CVSS', 'Severity', 'Risk']:
                severity_section = advisory_soup.find(text=re.compile(f'{term}', re.I))
                if severity_section:
                    # Get nearby text
                    parent = severity_section.parent
                    surrounding_text = parent.get_text() + " " + (parent.find_next_sibling() or "").get_text()
                    severity_text = surrounding_text
                    break
            
            severity = self.parse_severity(severity_text)
            if not severity or severity not in ["Critical", "High"]:
                continue
                
            # Extract CVE
            cve_id = self.extract_cve(advisory_content)
            
            # Extract publication date
            date_text = None
            date_section = advisory_soup.find('span', {'class': 'rn_Element'})
            if date_section:
                date_text = date_section.get_text()
            
            published_date = self.extract_date(date_text) if date_text else "N/A"
            
            # Extract affected products
            product_name = "Rockwell Automation Products"
            product_section = advisory_soup.find(text=re.compile('Affected|Vulnerable|Products', re.I))
            if product_section:
                parent = product_section.parent
                product_text = ""
                for sibling in parent.find_next_siblings()[:3]:  # Look at next few siblings
                    product_text += sibling.get_text() + " "
                
                if product_text:
                    product_name = product_text[:100]  # Limit length
            
            # Extract mitigation
            mitigation = "See advisory for details"
            for term in ['Mitigation', 'Remediation', 'Solution', 'Workaround']:
                mitigation_section = advisory_soup.find(text=re.compile(f'{term}', re.I))
                if mitigation_section:
                    parent = mitigation_section.parent
                    mitigation_text = ""
                    for sibling in parent.find_next_siblings()[:3]:  # Look at next few siblings
                        mitigation_text += sibling.get_text() + " "
                    
                    if mitigation_text:
                        mitigation = mitigation_text[:200]  # Limit length
                        break
            
            # Create vulnerability entry
            vulnerability = Vulnerability(
                product_name=product_name,
                product_version="See advisory for details",
                oem_name=self.name,
                severity_level=severity,
                description=advisory_title,
                mitigation_strategy=mitigation,
                published_date=published_date,
                unique_id=cve_id,
                url=advisory_url
            )
            
            vulnerabilities.append(vulnerability)
            
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


@ScraperRegistry.register
class ABBScraper(OEMScraper):
    """Scraper for ABB Cybersecurity Alerts."""
    
    def __init__(self):
        super().__init__("ABB", "https://search-ext.abb.com/library/Download.aspx?DocumentID=9AKK107991A9693&LanguageCode=en&DocumentPartId=&Action=Launch")
        self.alerts_url = "https://search-ext.abb.com/library/Download.aspx?DocumentID=9AKK107991A9693&LanguageCode=en&DocumentPartId=&Action=Launch"
        
    def scrape(self):
        """Scrape ABB Cybersecurity Advisories."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        # ABB provides a PDF with all advisories, which is harder to scrape
        # As a workaround, we'll search for recent ABB CVEs in their web pages
        search_url = "https://new.abb.com/search?query=CVE"
        
        page_content = self.get_page(search_url)
        if not page_content:
            return []
            
        soup = BeautifulSoup(page_content, 'lxml')
        vulnerabilities = []
        
        # Find search results
        search_results = soup.select('.search-result-items .search-result-item')
        
        for result in search_results[:20]:  # Process the most recent 20 results
            title_element = result.select_one('.search-result-title a')
            if not title_element:
                continue
                
            advisory_title = title_element.get_text().strip()
            advisory_url = urljoin(search_url, title_element.get('href', ''))
            
            # Only process security advisories
            if not any(term in advisory_title.lower() for term in ['security', 'vulnerability', 'advisory', 'cve']):
                continue
                
            # Get advisory details
            advisory_content = self.get_page(advisory_url)
            if not advisory_content:
                continue
                
            advisory_soup = BeautifulSoup(advisory_content, 'lxml')
            
            # Extract CVE
            cve_id = self.extract_cve(advisory_content)
            if cve_id == "N/A":
                continue  # Skip if no CVE found
                
            # Check for severity mentions
            severity_text = None
            for term in ['CVSS', 'Severity', 'Risk']:
                severity_section = advisory_soup.find(text=re.compile(f'{term}', re.I))
                if severity_section:
                    # Get parent paragraph
                    parent = severity_section.parent
                    severity_text = parent.get_text()
                    break
            
            # If no explicit severity, search the entire content
            if not severity_text:
                severity_text = advisory_content
            
            severity = self.parse_severity(severity_text)
            if not severity or severity not in ["Critical", "High"]:
                continue
                
            # Extract publication date
            date_text = None
            date_element = advisory_soup.select_one('.publication-date')
            if date_element:
                date_text = date_element.get_text()
            
            published_date = self.extract_date(date_text) if date_text else "N/A"
            
            # Extract mitigation
            mitigation = "See advisory for details"
            for term in ['Mitigation', 'Remediation', 'Solution', 'Workaround']:
                mitigation_section = advisory_soup.find(text=re.compile(f'{term}', re.I))
                if mitigation_section:
                    parent = mitigation_section.parent
                    mitigation = parent.get_text()[:200]  # Limit length
                    break
            
            # Create vulnerability entry
            vulnerability = Vulnerability(
                product_name="ABB Products",
                product_version="See advisory for details",
                oem_name=self.name,
                severity_level=severity,
                description=advisory_title,
                mitigation_strategy=mitigation,
                published_date=published_date,
                unique_id=cve_id,
                url=advisory_url
            )
            
            vulnerabilities.append(vulnerability)
            
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities


@ScraperRegistry.register
class HPEScraper(OEMScraper):
    """Scraper for HPE Security Bulletins."""
    
    def __init__(self):
        super().__init__("HPE", "https://support.hpe.com/hpesc/public/docDisplay?docId=emr_na-hpesbhf03971en_us")
        
    def scrape(self):
        """Scrape HPE Security Bulletins."""
        logger.info(f"Scraping {self.name} for vulnerabilities")
        
        # HPE provides a security bulletin page with all recent advisories
        search_url = "https://support.hpe.com/hpesc/public/home/documentHome?sp4ts.oid=null&documentType=HPESB"
        
        page_content = self.get_page(search_url)
        if not page_content:
            return []
            
        soup = BeautifulSoup(page_content, 'lxml')
        vulnerabilities = []
        
        # Find bulletin links
        bulletin_links = soup.select('a[href*="docDisplay"]')
        
        for link in bulletin_links[:20]:  # Process the most recent 20 bulletins
            bulletin_title = link.get_text().strip()
            bulletin_url = urljoin(search_url, link.get('href', ''))
            
            # Get bulletin details
            bulletin_content = self.get_page(bulletin_url)
            if not bulletin_content:
                continue
                
            bulletin_soup = BeautifulSoup(bulletin_content, 'lxml')
            
            # Extract CVE
            cve_id = self.extract_cve(bulletin_content)
            
            # Check for severity mentions
            severity_text = None
            for term in ['CVSS', 'Severity', 'Risk']:
                severity_section = bulletin_soup.find(text=re.compile(f'{term}', re.I))
                if severity_section:
                    # Get surrounding text
                    parent = severity_section.parent
                    surrounding_text = parent.get_text() + " " + (parent.find_next_sibling() or "").get_text()
                    severity_text = surrounding_text
                    break
            
            # If no explicit severity, try to find it in the title
            if not severity_text:
                severity_text = bulletin_title
            
            severity = self.parse_severity(severity_text)
            if not severity or severity not in ["Critical", "High"]:
                continue
                
            # Extract publication date
            date_text = None
            date_section = bulletin_soup.find(text=re.compile('Date|Published|Release', re.I))
            if date_section:
                parent = date_section.parent
                for sibling in parent.find_next_siblings():
                    if sibling.get_text():
                        date_text = sibling.get_text()
                        break
            
            published_date = self.extract_date(date_text) if date_text else "N/A"
            
            # Extract affected products
            product_name = "HPE Products"
            product_section = bulletin_soup.find(text=re.compile('Affected|Vulnerable|Products', re.I))
            if product_section:
                parent = product_section.parent
                product_text = ""
                for sibling in parent.find_next_siblings()[:3]:  # Look at next few siblings
                    product_text += sibling.get_text() + " "
                
                if product_text:
                    product_name = product_text[:100]  # Limit length
            
            # Extract mitigation
            mitigation = "See advisory for details"
            for term in ['Mitigation', 'Remediation', 'Resolution']:
                mitigation_section = bulletin_soup.find(text=re.compile(f'{term}', re.I))
                if mitigation_section:
                    parent = mitigation_section.parent
                    mitigation_text = ""
                    for sibling in parent.find_next_siblings()[:3]:  # Look at next few siblings
                        mitigation_text += sibling.get_text() + " "
                    
                    if mitigation_text:
                        mitigation = mitigation_text[:200]  # Limit length
                        break
            
            # Create vulnerability entry
            vulnerability = Vulnerability(
                product_name=product_name,
                product_version="See advisory for details",
                oem_name=self.name,
                severity_level=severity,
                description=bulletin_title,
                mitigation_strategy=mitigation,
                published_date=published_date,
                unique_id=cve_id,
                url=bulletin_url
            )
            
            vulnerabilities.append(vulnerability)
            
        logger.info(f"Found {len(vulnerabilities)} Critical/High vulnerabilities from {self.name}")
        return vulnerabilities 