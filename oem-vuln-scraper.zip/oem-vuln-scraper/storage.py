#!/usr/bin/env python3
"""
Storage module for the OEM Vulnerability Scraper.

This module handles persistence of vulnerabilities to avoid duplicate reporting.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger("storage")

class VulnerabilityStorage:
    """Storage manager for vulnerabilities."""
    
    def __init__(self, storage_file="vuln_database.json"):
        """Initialize storage with a file path."""
        self.storage_file = storage_file
        self.vulnerabilities = {}
        self._load()
    
    def _load(self):
        """Load vulnerabilities from storage file."""
        if not os.path.exists(self.storage_file):
            logger.info(f"Storage file {self.storage_file} does not exist, creating a new one")
            self._save()
            return
            
        try:
            with open(self.storage_file, 'r') as f:
                self.vulnerabilities = json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            logger.error(f"Error loading vulnerability database: {e}")
            self.vulnerabilities = {}
    
    def _save(self):
        """Save vulnerabilities to storage file."""
        try:
            with open(self.storage_file, 'w') as f:
                json.dump(self.vulnerabilities, f, indent=2)
        except IOError as e:
            logger.error(f"Error saving vulnerability database: {e}")
    
    def add_vulnerability(self, vulnerability):
        """
        Add a vulnerability to storage.
        
        Returns True if it's a new or updated vulnerability, False if it's already known.
        """
        # Use CVE ID or a combination of vendor, product, and description as unique key
        if vulnerability.unique_id != "N/A":
            key = vulnerability.unique_id
        else:
            key = f"{vulnerability.oem_name}_{vulnerability.product_name}_{hash(vulnerability.description)}"
            
        # Check if this vulnerability is already known
        if key in self.vulnerabilities:
            # Check if there are any updates
            existing = self.vulnerabilities[key]
            if existing.get('severity_level') == vulnerability.severity_level and \
               existing.get('description') == vulnerability.description and \
               existing.get('mitigation_strategy') == vulnerability.mitigation_strategy:
                return False
                
        # Store as new or updated vulnerability
        self.vulnerabilities[key] = vulnerability.to_dict()
        self._save()
        return True
        
    def get_recent_vulnerabilities(self, days=7):
        """Get vulnerabilities discovered in the last N days."""
        recent_vulns = []
        cutoff_date = datetime.now() - timedelta(days=days)
        
        for vuln_id, vuln_data in self.vulnerabilities.items():
            # Try to parse the last_updated field
            try:
                last_updated = datetime.strptime(vuln_data.get('last_updated', ''), '%Y-%m-%d %H:%M:%S')
                if last_updated >= cutoff_date:
                    recent_vulns.append(vuln_data)
            except ValueError:
                # If date parsing fails, include it just in case
                recent_vulns.append(vuln_data)
                
        return recent_vulns
        
    def get_all_vulnerabilities(self):
        """Get all stored vulnerabilities."""
        return list(self.vulnerabilities.values())
        
    def clear_old_vulnerabilities(self, days=90):
        """Remove vulnerabilities older than N days."""
        cutoff_date = datetime.now() - timedelta(days=days)
        keys_to_remove = []
        
        for vuln_id, vuln_data in self.vulnerabilities.items():
            try:
                last_updated = datetime.strptime(vuln_data.get('last_updated', ''), '%Y-%m-%d %H:%M:%S')
                if last_updated < cutoff_date:
                    keys_to_remove.append(vuln_id)
            except ValueError:
                # Keep entries with invalid dates
                pass
                
        for key in keys_to_remove:
            del self.vulnerabilities[key]
            
        if keys_to_remove:
            self._save()
            logger.info(f"Removed {len(keys_to_remove)} old vulnerabilities from storage")
            
    def export_csv(self, filepath):
        """Export all vulnerabilities to a CSV file."""
        import csv
        
        # Standard vulnerability fields
        standard_fields = [
            'unique_id', 'oem_name', 'product_name', 'product_version', 
            'severity_level', 'description', 'mitigation_strategy', 
            'remediation_steps', 'patch_links',
            'published_date', 'url', 'last_updated'
        ]
        
        # Compliance framework fields
        compliance_fields = [
            'nist_csf_controls', 'iso27001_controls', 'iec62443_controls'
        ]
        
        # Combine all fields
        fieldnames = standard_fields + compliance_fields
                     
        try:
            # Try to import compliance mapper
            try:
                from compliance_mapping import get_compliance_mapper
                mapper = get_compliance_mapper()
                has_compliance = True
            except ImportError:
                has_compliance = False
                logger.warning("Compliance mapping module not available, exporting without compliance information")
            
            with open(filepath, 'w', newline='', encoding='utf-8') as csvfile:
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                writer.writeheader()
                
                # Write each vulnerability to the CSV
                for vuln_id, vuln_data in self.vulnerabilities.items():
                    # Clean up any newlines in text fields to prevent CSV format issues
                    cleaned_data = {}
                    for k, v in vuln_data.items():
                        if isinstance(v, str):
                            # Replace newlines with space in string fields to maintain CSV format
                            cleaned_data[k] = v.replace('\n', ' ').replace('\r', '')
                        else:
                            cleaned_data[k] = v
                    
                    # Start with standard fields
                    row_data = {k: cleaned_data.get(k, '') for k in standard_fields}
                    
                    # Add compliance fields if available
                    if has_compliance:
                        try:
                            # Create a temporary Vulnerability object to use the mapper
                            from oem_scraper import Vulnerability
                            temp_vuln = Vulnerability(
                                product_name=vuln_data.get('product_name', 'N/A'),
                                product_version=vuln_data.get('product_version', 'N/A'),
                                oem_name=vuln_data.get('oem_name', 'N/A'),
                                severity_level=vuln_data.get('severity_level', 'N/A'),
                                description=vuln_data.get('description', 'N/A'),
                                mitigation_strategy=vuln_data.get('mitigation_strategy', 'N/A'),
                                remediation_steps=vuln_data.get('remediation_steps', 'N/A'),
                                patch_links=vuln_data.get('patch_links', 'N/A'),
                                published_date=vuln_data.get('published_date', 'N/A'),
                                unique_id=vuln_data.get('unique_id', 'N/A'),
                                url=vuln_data.get('url', 'N/A')
                            )
                            
                            # Get compliance mappings
                            compliance_map = mapper.map_vulnerability(temp_vuln)
                            
                            # Extract controls for each framework
                            nist_controls = []
                            iso_controls = []
                            iec_controls = []
                            
                            for framework, requirements in compliance_map.items():
                                control_ids = [req.control_id for req in requirements]
                                if framework == "NIST Cybersecurity Framework":
                                    nist_controls = control_ids
                                elif framework == "ISO 27001":
                                    iso_controls = control_ids
                                elif framework == "IEC 62443":
                                    iec_controls = control_ids
                            
                            # Add to row data
                            row_data['nist_csf_controls'] = ", ".join(nist_controls)
                            row_data['iso27001_controls'] = ", ".join(iso_controls)
                            row_data['iec62443_controls'] = ", ".join(iec_controls)
                        except Exception as e:
                            logger.error(f"Error getting compliance data for {vuln_id}: {e}")
                            row_data['nist_csf_controls'] = ""
                            row_data['iso27001_controls'] = ""
                            row_data['iec62443_controls'] = ""
                    else:
                        # No compliance module available
                        row_data['nist_csf_controls'] = ""
                        row_data['iso27001_controls'] = ""
                        row_data['iec62443_controls'] = ""
                    
                    # Write the row
                    writer.writerow(row_data)
                    
            logger.info(f"Exported {len(self.vulnerabilities)} vulnerabilities to {filepath}")
            return True
        except IOError as e:
            logger.error(f"Error exporting to CSV: {e}")
            return False 