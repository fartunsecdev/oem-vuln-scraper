#!/usr/bin/env python3
"""
Setup script for OEM Vulnerability Scraper.

This script helps with the initial setup of the vulnerability scraper.
"""

import os
import sys
import shutil
import logging
import argparse
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[logging.StreamHandler()]
)
logger = logging.getLogger("setup")

def setup_environment():
    """Set up the .env file for configuration."""
    env_file = Path(".env")
    example_env = Path(".env.example")
    
    if env_file.exists():
        logger.info(f"{env_file} already exists. Skipping environment setup.")
        return
        
    if not example_env.exists():
        logger.error(f"{example_env} not found. Cannot set up environment.")
        return
        
    # Copy the example file
    shutil.copy(example_env, env_file)
    logger.info(f"Created {env_file} from {example_env}. Please edit it with your configuration.")

def setup_directories():
    """Create necessary directories."""
    os.makedirs("logs", exist_ok=True)
    logger.info("Created logs directory.")

def check_dependencies():
    """Check if all required dependencies are installed."""
    try:
        import requests
        import bs4
        import schedule
        import dotenv
        import feedparser
        import tqdm
        logger.info("All required dependencies are installed.")
        return True
    except ImportError as e:
        logger.error(f"Missing dependency: {e}")
        logger.error("Please install dependencies with: pip install -r requirements.txt")
        return False

def main():
    """Main setup function."""
    parser = argparse.ArgumentParser(description="Set up OEM Vulnerability Scraper")
    parser.add_argument("--force", action="store_true", help="Force setup even if already configured")
    args = parser.parse_args()
    
    logger.info("Starting setup for OEM Vulnerability Scraper")
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Set up directories
    setup_directories()
    
    # Set up environment file
    setup_environment()
    
    logger.info("Setup complete! Follow these next steps:")
    logger.info("1. Edit the .env file with your configuration")
    logger.info("2. Test the scraper with: python main.py --run-once")
    logger.info("3. Test email notification with: python main.py --test-email")
    logger.info("4. Run the scraper as a service with: python main.py")

if __name__ == "__main__":
    main() 