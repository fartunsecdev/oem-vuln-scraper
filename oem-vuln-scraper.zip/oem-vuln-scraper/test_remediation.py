#!/usr/bin/env python3
"""
Test script to verify remediation functionality.
"""

import json
from oem_scraper import Vulnerability
from storage import VulnerabilityStorage

# Create a test vulnerability with remediation information
test_vuln = Vulnerability(
    product_name="Test Product",
    product_version="1.0",
    oem_name="Test Vendor",
    severity_level="Critical",
    description="This is a test vulnerability for demonstration purposes",
    mitigation_strategy="Update to the latest version",
    remediation_steps="""
1. Download the patch from the vendor website
2. Install the patch using administrator privileges
3. Restart the system to complete the installation
4. Verify the patch is applied by checking the version number
""",
    patch_links="""
Official Patch: https://example.com/patch/123
Alternative Download: https://mirror.example.com/patch/123
Security Advisory: https://example.com/advisory/CVE-2025-1234
""",
    published_date="2025-04-05",
    unique_id="CVE-2025-1234",
    url="https://example.com/advisory/CVE-2025-1234"
)

# Create a storage instance
storage = VulnerabilityStorage()

# Add the test vulnerability
storage.add_vulnerability(test_vuln)

# Export to CSV
storage.export_csv("test_vulnerabilities.csv")

# Print the email format that would be sent
print("\nEMAIL NOTIFICATION FORMAT:")
print("=" * 80)
print(test_vuln.to_email_format())

print("\nTest complete. Check test_vulnerabilities.csv for the exported data.")

# For demonstration, also show how the enhanced email notification would look
from notifier import EmailNotifier

notifier = EmailNotifier()
email_body = notifier._create_email_body([test_vuln])

print("\nENHANCED EMAIL NOTIFICATION FORMAT:")
print("=" * 80)
print(email_body) 