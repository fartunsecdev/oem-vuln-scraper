#!/usr/bin/env python3
"""
Compliance Mapping module for the OEM Vulnerability Scraper.

This module maps vulnerabilities to various compliance frameworks and regulations.
"""

import re
import logging
from dataclasses import dataclass
from typing import List, Dict, Optional, Set

logger = logging.getLogger("compliance_mapping")

@dataclass
class ComplianceRequirement:
    """Represents a specific compliance requirement."""
    framework: str        # e.g., "NIST CSF", "ISO 27001", "IEC 62443"
    control_id: str       # e.g., "ID.AM-2", "A.12.6.1", "SR 3.3"
    description: str      # Brief description of the control
    category: str         # Category within the framework

class ComplianceFramework:
    """Base class for compliance frameworks."""
    
    def __init__(self, name: str):
        self.name = name
        self.requirements: Dict[str, ComplianceRequirement] = {}
        self._initialize_requirements()
    
    def _initialize_requirements(self):
        """Initialize the requirements for this framework."""
        raise NotImplementedError("Subclasses must implement this method")
    
    def map_vulnerability(self, vulnerability) -> List[ComplianceRequirement]:
        """Map a vulnerability to relevant compliance requirements."""
        raise NotImplementedError("Subclasses must implement this method")

class NISTFramework(ComplianceFramework):
    """NIST Cybersecurity Framework implementation."""
    
    def __init__(self):
        super().__init__("NIST Cybersecurity Framework")
    
    def _initialize_requirements(self):
        """Initialize NIST CSF requirements."""
        self.requirements = {
            "ID.AM-2": ComplianceRequirement(
                framework=self.name,
                control_id="ID.AM-2",
                description="Software platforms and applications within the organization are inventoried",
                category="Asset Management"
            ),
            "ID.AM-3": ComplianceRequirement(
                framework=self.name,
                control_id="ID.AM-3",
                description="Organizational communication and data flows are mapped",
                category="Asset Management"
            ),
            "ID.RA-1": ComplianceRequirement(
                framework=self.name,
                control_id="ID.RA-1",
                description="Asset vulnerabilities are identified and documented",
                category="Risk Assessment"
            ),
            "PR.IP-12": ComplianceRequirement(
                framework=self.name,
                control_id="PR.IP-12",
                description="A vulnerability management plan is developed and implemented",
                category="Information Protection Processes and Procedures"
            ),
            "DE.CM-8": ComplianceRequirement(
                framework=self.name,
                control_id="DE.CM-8",
                description="Vulnerability scans are performed",
                category="Security Continuous Monitoring"
            ),
            "RS.MI-3": ComplianceRequirement(
                framework=self.name,
                control_id="RS.MI-3",
                description="Newly identified vulnerabilities are mitigated or documented as accepted risks",
                category="Mitigation"
            )
        }
    
    def map_vulnerability(self, vulnerability) -> List[ComplianceRequirement]:
        """Map vulnerability to NIST CSF requirements."""
        relevant_requirements = []
        
        # All vulnerabilities map to these NIST requirements
        base_requirements = ["ID.RA-1", "PR.IP-12", "DE.CM-8"]
        for req_id in base_requirements:
            relevant_requirements.append(self.requirements[req_id])
        
        # Critical vulnerabilities also map to mitigation requirements
        if vulnerability.severity_level in ["Critical", "High"]:
            relevant_requirements.append(self.requirements["RS.MI-3"])
        
        return relevant_requirements

class ISO27001Framework(ComplianceFramework):
    """ISO 27001 framework implementation."""
    
    def __init__(self):
        super().__init__("ISO 27001")
    
    def _initialize_requirements(self):
        """Initialize ISO 27001 requirements."""
        self.requirements = {
            "A.12.6.1": ComplianceRequirement(
                framework=self.name,
                control_id="A.12.6.1",
                description="Management of technical vulnerabilities",
                category="Technical Vulnerability Management"
            ),
            "A.14.2.8": ComplianceRequirement(
                framework=self.name,
                control_id="A.14.2.8",
                description="System security testing",
                category="Security in Development and Support Processes"
            ),
            "A.18.2.3": ComplianceRequirement(
                framework=self.name,
                control_id="A.18.2.3",
                description="Technical compliance review",
                category="Compliance Review"
            ),
            "A.16.1.3": ComplianceRequirement(
                framework=self.name,
                control_id="A.16.1.3",
                description="Reporting information security weaknesses",
                category="Information Security Incident Management"
            ),
            "A.16.1.4": ComplianceRequirement(
                framework=self.name,
                control_id="A.16.1.4",
                description="Assessment of and decision on information security events",
                category="Information Security Incident Management"
            )
        }
    
    def map_vulnerability(self, vulnerability) -> List[ComplianceRequirement]:
        """Map vulnerability to ISO 27001 requirements."""
        relevant_requirements = []
        
        # All vulnerabilities map to these ISO requirements
        base_requirements = ["A.12.6.1", "A.14.2.8", "A.18.2.3"]
        for req_id in base_requirements:
            relevant_requirements.append(self.requirements[req_id])
        
        # Critical and high vulnerabilities also map to incident management
        if vulnerability.severity_level in ["Critical", "High"]:
            relevant_requirements.append(self.requirements["A.16.1.3"])
            relevant_requirements.append(self.requirements["A.16.1.4"])
        
        return relevant_requirements

class IEC62443Framework(ComplianceFramework):
    """IEC 62443 framework for Industrial Control Systems security."""
    
    def __init__(self):
        super().__init__("IEC 62443")
    
    def _initialize_requirements(self):
        """Initialize IEC 62443 requirements."""
        self.requirements = {
            "SR 3.3": ComplianceRequirement(
                framework=self.name,
                control_id="SR 3.3",
                description="Security functionality verification",
                category="System Integrity"
            ),
            "SR 3.4": ComplianceRequirement(
                framework=self.name,
                control_id="SR 3.4",
                description="Software and information integrity",
                category="System Integrity"
            ),
            "SR 6.2": ComplianceRequirement(
                framework=self.name,
                control_id="SR 6.2",
                description="Continuous monitoring",
                category="Monitoring"
            ),
            "SR 7.6": ComplianceRequirement(
                framework=self.name,
                control_id="SR 7.6",
                description="Network and security configuration settings",
                category="Network Segmentation"
            ),
            "EDR 3.12": ComplianceRequirement(
                framework=self.name,
                control_id="EDR 3.12",
                description="Provisioning product security updates",
                category="Security Updates"
            )
        }
    
    def map_vulnerability(self, vulnerability) -> List[ComplianceRequirement]:
        """Map vulnerability to IEC 62443 requirements."""
        relevant_requirements = []
        
        # Default requirements for all vulnerabilities
        base_requirements = ["SR 3.3", "SR 6.2"]
        for req_id in base_requirements:
            relevant_requirements.append(self.requirements[req_id])
        
        # Check if this is an OT/ICS vulnerability
        ot_vendors = ["Siemens", "Schneider Electric", "Rockwell Automation", "ABB"]
        if any(vendor.lower() in vulnerability.oem_name.lower() for vendor in ot_vendors):
            relevant_requirements.append(self.requirements["SR 7.6"])
        
        # All critical and high vulnerabilities require updates
        if vulnerability.severity_level in ["Critical", "High"]:
            relevant_requirements.append(self.requirements["EDR 3.12"])
            relevant_requirements.append(self.requirements["SR 3.4"])
        
        return relevant_requirements

class ComplianceMapper:
    """Maps vulnerabilities to compliance requirements across frameworks."""
    
    def __init__(self):
        """Initialize with supported compliance frameworks."""
        self.frameworks = {
            "NIST CSF": NISTFramework(),
            "ISO 27001": ISO27001Framework(),
            "IEC 62443": IEC62443Framework()
        }
    
    def map_vulnerability(self, vulnerability) -> Dict[str, List[ComplianceRequirement]]:
        """Map a vulnerability to all relevant compliance requirements."""
        compliance_map = {}
        
        for framework_name, framework in self.frameworks.items():
            requirements = framework.map_vulnerability(vulnerability)
            if requirements:
                compliance_map[framework_name] = requirements
        
        return compliance_map
    
    def get_compliance_report(self, vulnerability) -> str:
        """Generate a human-readable compliance report for a vulnerability."""
        compliance_map = self.map_vulnerability(vulnerability)
        
        if not compliance_map:
            return "No compliance mappings available for this vulnerability."
        
        report = "COMPLIANCE REQUIREMENTS:\n"
        
        for framework_name, requirements in compliance_map.items():
            report += f"\n{framework_name}:\n"
            for req in requirements:
                report += f"  • {req.control_id}: {req.description} (Category: {req.category})\n"
        
        return report

# Helper function to get compliance mapper instance
def get_compliance_mapper():
    """Get or create a ComplianceMapper instance."""
    return ComplianceMapper() 