#!/usr/bin/env python3
"""
OEM Vulnerability Scraper

This script scrapes OEM websites for vulnerability information and sends
notifications when critical or high severity vulnerabilities are found.
"""

import os
import sys
import time
import logging
import argparse
import datetime
import traceback
import schedule
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Import our modules
from oem_scraper import get_all_vulnerabilities, Vulnerability
from storage import VulnerabilityStorage
from notifier import EmailNotifier

# Configure logging
logging.basicConfig(
    level=os.getenv("LOG_LEVEL", "INFO"),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler("vuln_scraper.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger("main")

def setup_argparse():
    """Setup command line argument parsing."""
    parser = argparse.ArgumentParser(description="OEM Vulnerability Scraper")
    parser.add_argument(
        "--run-once", 
        action="store_true", 
        help="Run the scraper once and exit"
    )
    parser.add_argument(
        "--test-email", 
        action="store_true", 
        help="Send a test email and exit"
    )
    parser.add_argument(
        "--export-csv", 
        metavar="FILENAME",
        help="Export vulnerability database to CSV file and exit"
    )
    parser.add_argument(
        "--interval", 
        type=int, 
        default=int(os.getenv("SCRAPE_INTERVAL_HOURS", 6)),
        help="Interval in hours between scraping runs when running as a service"
    )
    parser.add_argument(
        "--compliance-report",
        action="store_true",
        help="Generate compliance report for stored vulnerabilities and exit"
    )
    parser.add_argument(
        "--compliance-framework",
        choices=["all", "NIST", "ISO27001", "IEC62443"],
        default="all",
        help="Specify compliance framework for the report (default: all)"
    )
    return parser.parse_args()

def scrape_and_notify():
    """Main function to scrape vulnerabilities and send notifications."""
    logger.info("Starting vulnerability scraping run")
    
    # Initialize storage
    storage = VulnerabilityStorage()
    
    # Initialize notifier
    notifier = EmailNotifier()
    
    try:
        # Scrape for vulnerabilities
        vulnerabilities = get_all_vulnerabilities()
        
        # Filter for only critical and high vulnerabilities
        critical_high_vulns = [v for v in vulnerabilities if v.is_critical_or_high()]
        
        if not critical_high_vulns:
            logger.info("No critical or high vulnerabilities found in this run")
            return
            
        # New vulnerabilities to notify about
        new_vulns = []
        
        # Add vulnerabilities to storage and track new ones
        for vuln in critical_high_vulns:
            if storage.add_vulnerability(vuln):
                new_vulns.append(vuln)
                
        # Send notification if there are new vulnerabilities
        if new_vulns:
            logger.info(f"Found {len(new_vulns)} new critical/high vulnerabilities")
            if notifier.is_configured():
                notifier.send_vulnerability_notification(new_vulns)
            else:
                logger.warning("Email notification not configured, skipping notification")
                
                # Print to console instead
                logger.info("New vulnerabilities found:")
                for vuln in new_vulns:
                    logger.info(f"{vuln.oem_name} - {vuln.unique_id} - {vuln.severity_level}")
        else:
            logger.info("No new critical/high vulnerabilities found")
            
        # Clean up old vulnerabilities
        storage.clear_old_vulnerabilities(days=90)
        
    except Exception as e:
        logger.error(f"Error in scrape_and_notify: {e}")
        logger.error(traceback.format_exc())

def main():
    """Main entry point."""
    args = setup_argparse()
    
    # Initialize storage
    storage = VulnerabilityStorage()
    
    # Test email notification if requested
    if args.test_email:
        logger.info("Sending test email...")
        notifier = EmailNotifier()
        if notifier.send_test_email():
            logger.info("Test email sent successfully")
        else:
            logger.error("Failed to send test email")
        return
        
    # Export to CSV if requested
    if args.export_csv:
        logger.info(f"Exporting vulnerability database to {args.export_csv}")
        if storage.export_csv(args.export_csv):
            logger.info("Export completed successfully")
        else:
            logger.error("Export failed")
        return

    # Generate compliance report if requested
    if args.compliance_report:
        generate_compliance_report(storage, args.compliance_framework)
        return
    
    # Run once if requested
    if args.run_once:
        logger.info("Running scraper once")
        scrape_and_notify()
        return
        
    # Run as a service with scheduled intervals
    interval_hours = args.interval
    logger.info(f"Starting vulnerability scraper service, running every {interval_hours} hours")
    
    # Schedule the scraping job
    schedule.every(interval_hours).hours.do(scrape_and_notify)
    
    # Run once at startup
    scrape_and_notify()
    
    # Keep the scheduler running
    while True:
        schedule.run_pending()
        time.sleep(60)  # Sleep for 1 minute between checks

def generate_compliance_report(storage, framework):
    """Generate a compliance report for stored vulnerabilities."""
    logger.info(f"Generating compliance report for framework: {framework}")
    
    try:
        from compliance_mapping import get_compliance_mapper
        
        # Get the compliance mapper
        mapper = get_compliance_mapper()
        
        # Get all vulnerabilities
        vulnerabilities = storage.get_all_vulnerabilities()
        
        if not vulnerabilities:
            logger.info("No vulnerabilities found in the database.")
            print("No vulnerabilities found in the database.")
            return
        
        print(f"\nCOMPLIANCE REPORT\n{'-' * 50}")
        print(f"Total vulnerabilities: {len(vulnerabilities)}")
        print(f"Framework: {framework}")
        print(f"{'-' * 50}\n")
        
        # Count affected requirements per framework
        framework_counts = {}
        requirement_counts = {}
        
        for vuln_dict in vulnerabilities:
            # Create a temporary Vulnerability object to use the mapper
            from oem_scraper import Vulnerability
            vuln = Vulnerability(
                product_name=vuln_dict.get('product_name', 'N/A'),
                product_version=vuln_dict.get('product_version', 'N/A'),
                oem_name=vuln_dict.get('oem_name', 'N/A'),
                severity_level=vuln_dict.get('severity_level', 'N/A'),
                description=vuln_dict.get('description', 'N/A'),
                mitigation_strategy=vuln_dict.get('mitigation_strategy', 'N/A'),
                remediation_steps=vuln_dict.get('remediation_steps', 'N/A'),
                patch_links=vuln_dict.get('patch_links', 'N/A'),
                published_date=vuln_dict.get('published_date', 'N/A'),
                unique_id=vuln_dict.get('unique_id', 'N/A'),
                url=vuln_dict.get('url', 'N/A')
            )
            
            # Get compliance mapping
            compliance_map = mapper.map_vulnerability(vuln)
            
            # Filter by framework if specified
            if framework != "all":
                framework_key = None
                if framework == "NIST":
                    framework_key = "NIST Cybersecurity Framework"
                elif framework == "ISO27001":
                    framework_key = "ISO 27001"
                elif framework == "IEC62443":
                    framework_key = "IEC 62443"
                    
                if framework_key:
                    filtered_map = {}
                    if framework_key in compliance_map:
                        filtered_map[framework_key] = compliance_map[framework_key]
                    compliance_map = filtered_map
            
            # Count frameworks and requirements
            for framework_name, requirements in compliance_map.items():
                if framework_name not in framework_counts:
                    framework_counts[framework_name] = 0
                framework_counts[framework_name] += 1
                
                for req in requirements:
                    req_key = f"{framework_name}:{req.control_id}"
                    if req_key not in requirement_counts:
                        requirement_counts[req_key] = {"count": 0, "description": req.description, "category": req.category}
                    requirement_counts[req_key]["count"] += 1
        
        # Print framework summary
        print("FRAMEWORK COVERAGE SUMMARY:")
        for framework_name, count in framework_counts.items():
            print(f"{framework_name}: {count} vulnerabilities")
        print("")
        
        # Print top affected requirements
        print("TOP AFFECTED COMPLIANCE REQUIREMENTS:")
        sorted_reqs = sorted(requirement_counts.items(), key=lambda x: x[1]["count"], reverse=True)
        for i, (req_key, data) in enumerate(sorted_reqs[:10], 1):
            framework, control = req_key.split(":", 1)
            print(f"{i}. {framework} {control}: {data['count']} vulnerabilities")
            print(f"   Description: {data['description']}")
            print(f"   Category: {data['category']}")
            print("")
            
        # Print detailed report for critical/high vulnerabilities
        print("CRITICAL/HIGH VULNERABILITY COMPLIANCE DETAILS:")
        critical_high_vulns = [v for v in vulnerabilities if v.get('severity_level') in ['Critical', 'High']]
        
        for i, vuln_dict in enumerate(critical_high_vulns[:5], 1):  # Limit to first 5 to avoid too much output
            print(f"\n{i}. {vuln_dict.get('unique_id')} - {vuln_dict.get('product_name')}")
            print(f"   Severity: {vuln_dict.get('severity_level')}")
            print(f"   Vendor: {vuln_dict.get('oem_name')}")
            
            # Create a temporary Vulnerability object to use the mapper
            vuln = Vulnerability(
                product_name=vuln_dict.get('product_name', 'N/A'),
                product_version=vuln_dict.get('product_version', 'N/A'),
                oem_name=vuln_dict.get('oem_name', 'N/A'),
                severity_level=vuln_dict.get('severity_level', 'N/A'),
                unique_id=vuln_dict.get('unique_id', 'N/A')
            )
            
            # Print compliance report
            print(f"   Compliance Requirements:")
            compliance_map = mapper.map_vulnerability(vuln)
            
            # Filter by framework if specified
            if framework != "all":
                framework_key = None
                if framework == "NIST":
                    framework_key = "NIST Cybersecurity Framework"
                elif framework == "ISO27001":
                    framework_key = "ISO 27001"
                elif framework == "IEC62443":
                    framework_key = "IEC 62443"
                    
                if framework_key:
                    filtered_map = {}
                    if framework_key in compliance_map:
                        filtered_map[framework_key] = compliance_map[framework_key]
                    compliance_map = filtered_map
            
            for framework_name, requirements in compliance_map.items():
                print(f"     {framework_name}:")
                for req in requirements:
                    print(f"       - {req.control_id}: {req.description}")
        
        if len(critical_high_vulns) > 5:
            print(f"\n... and {len(critical_high_vulns) - 5} more critical/high vulnerabilities")
            
        print("\nFor a complete report, export the vulnerability database to CSV.")
        
    except ImportError:
        logger.error("Compliance mapping module not available")
        print("Error: Compliance mapping module not available.")
    except Exception as e:
        logger.error(f"Error generating compliance report: {e}")
        print(f"Error generating compliance report: {e}")
        logger.error(traceback.format_exc())

if __name__ == "__main__":
    main() 